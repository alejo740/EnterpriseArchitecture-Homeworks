package cs544.aop1;

public interface ICustomerDAO {
	public void save(Customer customer) ;
}
