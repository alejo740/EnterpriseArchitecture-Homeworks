package cs544.aop1;

public interface ICustomerService {
	public void addCustomer(String name, String email, String street,String city, String zip);
}
