package cs544.exercise16_1.bank.logging;

public interface ILogger {
    public void log (String logstring);
}
