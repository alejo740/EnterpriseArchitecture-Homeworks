package cs544.exercise16_1.bank.jms;

public interface IJMSSender {
	public void sendJMSMessage (String text);
}
