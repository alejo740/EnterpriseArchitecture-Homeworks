package cs544.sdi2;

public interface IInventoryService {
    public int getNumberInStock(int productNumber);
}
