package cs544.exercise25_2.service;

public interface ICalculator {

    public int calc(char operator, int number);

}
