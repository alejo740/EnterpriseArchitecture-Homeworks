package cs544.exercise25_2.service;

public interface IGreeting {
	 public String getMessage(Person person);
}
